import numpy as np

# Load the .npy file
data = np.load('orgin_page/has_viewd.npy')

# Now you can use the 'data' variable which contains the contents of the .npy file
print(data)
