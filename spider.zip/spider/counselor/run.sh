source /data/gaozhicheng/miniconda3/bin/activate llama3
python run.py --file_dir "/nfs-data/spiderman/content/temp/" --save_dir "/nfs-data/spiderman/result/temp/" --CUDA_VISIBLE_DEVICES "3,4,5"